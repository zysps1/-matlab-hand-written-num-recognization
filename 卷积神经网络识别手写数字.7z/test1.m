function test1
infor = imread('test1.jpg');
infor_g = rgb2gray(infor)
size(infor_g)
imwrite(infor_g, '1_g.bmp', 'bmp'); 